import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import styled, { createGlobalStyle } from "styled-components";
import Menu from "./Menu";
import Footer from "./Footer";
import Notices from "./Notices";
import QnA from "./QnA";
import Login from "./Login";
import SignPage1 from "./SignPage1";
import SignPage2 from "./SignPage2";
import SignPage3 from "./SignPage3";
import Header from "./Header";
import MobileHeader from "./MobileHeader";

const GlobalStyle = createGlobalStyle`

  @import url('https://fonts.googleapis.com/css?family=Noto+Sans+KR&display=swap');

  body { 
    background-color: #ffffff;
    margin: 0;
    padding: 0;
    text-align: center;
    font-family: 'Noto Sans KR', sans-serif;
  }
  
  div {
    margin: 0;
  }

  h1 {
    margin: 0;
  }

  a {
    text-decoration: none;
    color: #000;
  }

  header {
    background: #ffffff;
    z-index: 50;
  }
`;

const PcScreen = styled.div`
  @media all and (max-width: 1023px) {
    display: none;
  }
`;

const MobileScreen = styled.div`
  @media all and (min-width: 1024px) {
    display: none;
  }
`;

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      menuContent: [
        { id: 1, list: "판매", link: "" },
        { id: 2, list: "채팅", link: "" },
        { id: 3, list: "알림", link: "" },
        { id: 4, list: "고객센터", link: "" },
      ],

      topMenu: [
        { id: 1, list: "마이페이지", link: "" },
        { id: 2, list: "로그아웃", link: "" },
      ],
      category: [
        { id: 1, list: "의류" },
        { id: 2, list: "패션 잡화" },
        { id: 3, list: "유아용품" },
        { id: 4, list: "가구/인테리어" },
        { id: 5, list: "디지털" },
        { id: 6, list: "컴퓨터" },
        { id: 7, list: "스포츠 용품" },
        { id: 8, list: "뷰티" },
        { id: 9, list: "가전제품" },
        { id: 10, list: "자동차/공구" },
        { id: 11, list: "도서" },
        { id: 12, list: "기타" },
      ]
    };
  }
  render() {
    return (
      <Router>
        <GlobalStyle />
        
        <Switch>
          <Route exact path="/login" component={Login} />
          <Route path="/signPage1" component={SignPage1} />
          <Route path="/signPage2" component={SignPage2} />
          <Route path="/signPage3" component={SignPage3} />
          <Route
          path="/header"
          render={() => (
            <Header
              category={this.state.category}
              topMenu={this.state.topMenu}
              menuContent={this.state.menuContent}
            />
          )}
        />
        <Route
          path="/mobileheader"
          render={() => (
            <MobileHeader
              category={this.state.category}
              topMenu={this.state.topMenu}
              menuContent={this.state.menuContent}
            />
          )}
        />
          <Route path="/header" component={Menu} />
          <Route path="/qna" component={QnA} />
          <Route path="/footer" component={Footer} />
          <Route path="/notice" component={Notices} />
        </Switch>
      </Router>
    );
  }
}

export default App;
